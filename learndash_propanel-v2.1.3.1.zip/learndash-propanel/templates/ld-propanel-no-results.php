<?php
/**
 * Learndash ProPanel Widget Loading
 */
?>

<div>
	<strong class="note please-choose-filter"><?php esc_html_e( 'No Results Found.', 'ld_propanel' ); ?></strong>
</div>
